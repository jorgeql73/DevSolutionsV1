<?php

return [
    /*
    | ------------------------------------------------- -------------------------
    El | Líneas de idioma de recordatorio de contraseña
    | ------------------------------------------------- -------------------------
    El |
    El | Las siguientes líneas de idioma son las líneas predeterminadas que coinciden con los motivos
    El | que proporciona el agente de contraseñas para un intento de actualización de contraseña
    El | ha fallado, como un token no válido o una nueva contraseña no válida.
    El |
    */

    'reset'      => '¡Tu contraseña ha sido restablecida!' ,
    'enviado'       => '¡Hemos enviado por correo el enlace para restablecer tu contraseña!' ,
    'throttled' => 'Por favor espera antes de intentar de nuevo.' ,
    'token'      => 'El token de recuperación de contraseña es inválido' ,
    'user'       => 'No podemos encontrar ningún usuario con ese correo electrónico.' ,
];