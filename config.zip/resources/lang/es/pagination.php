<?php

return [
    /*
    | ------------------------------------------------- -------------------------
    El | Líneas de lenguaje de paginación
    | ------------------------------------------------- -------------------------
    El |
    El | La biblioteca del paginador utiliza las siguientes líneas de lenguaje para construir
    El | Los enlaces de paginación simples. Eres libre de cambiarlos a cualquier cosa
    El | desea personalizar sus vistas para que coincidan mejor con su aplicación.
    El |
    */

    'previous' => '& laquo; Anterior ' ,
    'next'      => 'Siguiente & raquo;' ,
];