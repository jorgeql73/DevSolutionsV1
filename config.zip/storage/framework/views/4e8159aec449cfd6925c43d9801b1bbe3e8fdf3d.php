
<?php $__env->startSection('title','Portafolio'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-10 col-lg-6 mx-auto">
                
                
                <form class="bg-white shadow rounded py-3 px-4"
                    method="POST" action="<?php echo e(route('Projects.update',$project)); ?>">
                    <?php echo method_field('PATCH'); ?>
                    <h1 class="display-5">Editar un proyecto</h1>
                    <hr>
                    <?php echo $__env->make('Projects._form',['btnText'=> 'Actualizar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ale\Desktop\Proyectos\DevSolutionV1\resources\views/Projects/edit.blade.php ENDPATH**/ ?>