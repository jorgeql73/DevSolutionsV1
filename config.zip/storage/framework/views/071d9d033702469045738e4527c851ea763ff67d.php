<?php if(session('status')): ?>
    <div class="alert alert-primary" rol="alert">
        <?php echo e(session('status')); ?>

        <button type="button"
            class="close"
            data-dismiss="alert"
            area-label="close">
            <span area-hidden="true">&times</span>

        </button>

    </div>

<?php endif; ?><?php /**PATH C:\Users\ale\Desktop\Proyectos\DevSolutionV1\resources\views/partials/session-status.blade.php ENDPATH**/ ?>