
<?php $__env->startSection('title','Portafolio'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
           
            <h2 class= "display-5 text-primary">Portafolio</h2>
            <hr border-color:#0400ff 2px>
            <?php if(auth()->guard()->check()): ?>
                <a class="btn btn-primary" href="<?php echo e(route('Projects.create')); ?>">Crear</a>
            <?php endif; ?>
        </div>
        <h4 class="lead text secondary mb-4">Proyectos realizados en el ámbito académico y personal</h4>

        <ul class="list-group">
            <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="list-group-item border-0 mb-3 shadow-sm">
                    <a class="d-flex justify-content-between align-items-center"
                        href="<?php echo e(route('Projects.show', $Project)); ?>">
                        <span class="text-secondary font-weight-bold">
                            <?php echo e($Project->title); ?>

                        </span>
                        <span class="text-black-50">
                            <?php echo e($Project->create_at); ?>

                        </span>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="list-group-item border-0 mb-3 shadow-sm">
                    No hay elementos para mostrar
                </li>
            <?php endif; ?>
            <?php echo e($projects ->links()); ?>

        </ul>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ale\Desktop\Proyectos\DevSolutionV1\resources\views/Projects/index.blade.php ENDPATH**/ ?>