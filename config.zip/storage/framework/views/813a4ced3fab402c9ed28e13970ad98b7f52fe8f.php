<nav class="navbar navbar-light navbar-expand-lg bg-white shadows-sm">
    <div class="container">
        <a class= "navbar-brand"href="<?php echo e(route('home')); ?>">
            <!-- <?php echo e(config('app.name')); ?> -->
            <img class="img-fluid " width="80em" src="/img/Logo.png" alt="Quiroga Jorge">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="nav nav-pills ml-auto">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(setActive('home')); ?>"
                        href="<?php echo e(route('home')); ?>">Inicio
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(setActive('Projects.*')); ?>" 
                        href="<?php echo e(route('Projects.index')); ?>">Proyectos
                    </a>
                </li>
                <!-- <li class="nav-item">
                    <a class="nav-link <?php echo e(setActive('#')); ?>"
                        href="<?php echo e(route('home')); ?>">Cursos
                    </a>
                </li> -->
                <li class="nav-item">
                    <a class="nav-link <?php echo e(setActive('contacto')); ?>"
                        href="<?php echo e(route('contacto')); ?>">Contacto
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(setActive('register')); ?>"
                        href="<?php echo e(route('register')); ?>">Registro
                    </a>
                </li>
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(setActive('login')); ?>"
                            href="<?php echo e(route('login')); ?>">Login
                        </a>
                    </li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="#" onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">Cerrar sesión</a></li>
                <?php endif; ?>
            </ul> 
        </div>
    </div>
</nav>
<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
    <?php echo csrf_field(); ?>
</form><?php /**PATH C:\Users\ale\Desktop\Proyectos\DevSolutionV1\resources\views/partials/Nav.blade.php ENDPATH**/ ?>