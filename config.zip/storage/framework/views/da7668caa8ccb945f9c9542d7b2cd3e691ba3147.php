
<?php $__env->startSection('title','Portafolio'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-10 col-lg-6 mx-auto">
        
                <form class="bg-white py-3 px-4 shadow rounded"
                    method="POST" action="<?php echo e(route('Projects.store')); ?>">
                    <h1 class="display-5">Nuevo proyecto</h1>
                    <hr>
                    <?php echo $__env->make('Projects._form', ['btnText'=> 'Guardar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ale\Desktop\Proyectos\DevSolutionV1\resources\views/Projects/create.blade.php ENDPATH**/ ?>