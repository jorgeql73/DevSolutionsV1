<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mensaje recibido</title>
</head>
<body>
    <p>Resiviste un mensaje de: <?php echo e($msj['name']); ?> - <?php echo e($msj['email']); ?> </p>
    <p><strong>Asunto</strong> <?php echo e($msj['subject']); ?></p>
    <p><strong>Contenido</strong> <?php echo e($msj['content']); ?></p>
</body>
</html><?php /**PATH C:\Users\ale\Desktop\Proyectos\DevSolutionV1\resources\views/email/Mensaje_resivido.blade.php ENDPATH**/ ?>