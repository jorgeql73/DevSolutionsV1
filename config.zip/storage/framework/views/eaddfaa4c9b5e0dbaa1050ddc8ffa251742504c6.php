<?php echo csrf_field(); ?>
<div class="form-group">
    <label for="title">Título del proyecto</label>
    <input class="form-control bg-light shadow-sm 
        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php else: ?> border-0 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "
                            
        id="title" name="title" value="<?php echo e(old('title')); ?>">
    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" roll="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<!-- <label>
    Titulo del proyecto <br>
    <input type="text" name="title" value="<?php echo e(old('title',$project->title)); ?>">
    <?php echo $errors->first('title', '<small><br>:message</small><br>'); ?>

</label>
<br> -->
<div class="form-group">
    <label for="url">URL del proyecto</label>
    <input class="form-control bg-light shadow-sm 
        <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php else: ?> border-0 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "
                            
        id="url" name="url" value="<?php echo e(old('url')); ?>">
    <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" roll="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<!-- <label>
    URL del proyecto <br>
    <input type="text" name="url" value="<?php echo e(old('url',$project->url)); ?>">
    <?php echo $errors->first('url', '<small><br>:message</small><br>'); ?>

</label>
<br> -->
<div class="form-group">
    <label for="description">Descripción del proyecto</label>
    <textarea class="form-control bg-light shadow-sm 
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php else: ?> border-0 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "
                            
        id="description" name="description"  value="<?php echo e(old('description')); ?>">
    </textarea>
    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" roll="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<!-- <label>
    Descripción del proyecto <br>
    <textarea name="description" value="<?php echo e(old('description',$project->descripton)); ?>"></textarea>
    <?php echo $errors->first('description', '<small><br>:message</small><br>'); ?>

</label>
<br> -->
<button class="btn btn-primary btn-lg btn-block"><?php echo e($btnText); ?></button>
<a class="btn btn-link btn-block" href="<?php echo e(route('Projects.index')); ?>">Cancelar</a><?php /**PATH C:\Users\ale\Desktop\Proyectos\DevSolutionV1\resources\views/Projects/_form.blade.php ENDPATH**/ ?>