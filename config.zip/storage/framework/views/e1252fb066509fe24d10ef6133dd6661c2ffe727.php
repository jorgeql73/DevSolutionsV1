
<?php $__env->startSection('title','Portafolio'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Es la pagina de Portafolio</h1>
    <ul>
        <?php $__empty_1 = true; $__currentLoopData = $Projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li><a href="<?php echo e(route('Portfolio.show', $Project)); ?>"><?php echo e($Project->title); ?><br><small><?php echo e($Project->description); ?></a></small></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li>No hay elementos para mostrar</li>
        <?php endif; ?>
        <?php echo e($Projects ->links()); ?>

    </ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ale\Desktop\Proyectos\DevSolutionV1\resources\views/Portfolio.blade.php ENDPATH**/ ?>