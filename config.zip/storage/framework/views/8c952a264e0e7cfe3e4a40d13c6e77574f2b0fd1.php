
<?php $__env->startSection('title', 'Portfolio | '. $project->title); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="bg-white p-5 shadow rounded">
        <h1><?php echo e($project -> title); ?></h1>
       
        <p class="text-secondary"><?php echo e($project -> description); ?></p>
        <a href="https://www.junados.com/"><?php echo e($project -> url); ?></a>
        
        <p class="text-black-50"><?php echo e($project -> created_at -> diffForHumans()); ?></p>
        <div class="d-flex justify-content-between align-items-center">
            <a href="<?php echo e(route('Projects.index')); ?>">Volver</a>
            <?php if(auth()->guard()->check()): ?>
                <div class="btn-group btn-group-sm">
                    <a class="btn btn-primary" href="<?php echo e(route('Projects.edit', $project)); ?>">Editar</a>
                    <a class="btn btn-danger" href="#" onclick="document.getElementById('delete-project').submit()">Eliminar</a>
                
                    <form class="d-none" id="delete-project" method="POST" action="<?php echo e(route('Projects.destroy', $project)); ?>" >
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ale\Desktop\Proyectos\DevSolutionV1\resources\views/Projects/show.blade.php ENDPATH**/ ?>